# Feedback-System
Feedback system developed in PHP, MYSql

To Run:
1) create an SQL database "feedback"
2) import SQL file present in the databse folder of the project file 
3) Place the project file in the root directory of your server
4) Navigate to the root directory for submitting feedback and "/admin" for viewing feedback
5) Default username: admin@admin.com , password: admin
